//
//  ContactInfoViewController.swift
//  ContactListApp
//
//  Created by student on 5/2/22.
//

import UIKit

class ContactInfoViewController: UIViewController {
    
    
    @IBOutlet weak var firstNameTextFeild: UITextField!
    
    @IBOutlet weak var lastNameTextFeild: UITextField!
    
    
    @IBOutlet weak var emailTextFeild: UITextField!
    
    
    @IBOutlet weak var phoneNumberTextFeild: UITextField!
    
    
    @IBOutlet weak var editButton: UIButton!
    
    var fName = ""
    var lName = ""
    var email = ""
    var phnNo: Int = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        firstNameTextFeild.text = fName
        lastNameTextFeild.text = lName
        emailTextFeild.text = email
        phoneNumberTextFeild.text = String(phnNo)
        
        firstNameTextFeild.isEnabled = false
        lastNameTextFeild.isEnabled = false
        emailTextFeild.isEnabled = false
        phoneNumberTextFeild.isEnabled = false

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func editActionButton(_ sender: Any) {
        contactEdit.email=email
        contactEdit.firstName=fName
        contactEdit.phnNum=phnNo
        contactEdit.lastName=lName
    }
    
    
    
   
    
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
