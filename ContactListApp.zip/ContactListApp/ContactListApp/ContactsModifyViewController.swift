//
//  ContactsModifyViewController.swift
//  ContactListApp
//
//  Created by student on 5/2/22.
//

import UIKit

class ContactsModifyViewController: UIViewController {
    
    
    @IBOutlet weak var firstNameTextFeild: UITextField!
    
    
    @IBOutlet weak var lastNameTextFeild: UITextField!
    
    
    @IBOutlet weak var emailTextFeild: UITextField!
    
    
    @IBOutlet weak var phoneNumberTextFeild: UITextField!
    
    
    @IBOutlet weak var deleteButton: UIButton!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    
    
    @IBOutlet weak var firstNameError: UILabel!
    
    @IBOutlet weak var lastNameError: UILabel!
    
    
    @IBOutlet weak var emailError: UILabel!
    
    @IBOutlet weak var phoneError: UILabel!
    
    var fName = ""
    var lName = ""
    var email = ""
    var phnNo: Int = 0
    
    var tempfName = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNameTextFeild.text = contactEdit.firstName
        lastNameTextFeild.text = contactEdit.lastName
        emailTextFeild.text = contactEdit.email
        phoneNumberTextFeild.text = String(contactEdit.phnNum)
        tempfName = firstNameTextFeild.text!

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func firstNameChanged(_ sender: Any) {
        if let firstname = firstNameTextFeild.text
        {
            if firstname.isEmpty == true{
                firstNameError.text = "Name cannot be empty"
                firstNameError.isHidden = false
            }else{
                firstNameError.isHidden = true
            }
        }
        
        checkForValidForm()
    }
    
    @IBAction func lastNameChanged(_ sender: Any) {
        if let lastName = lastNameTextFeild.text
        {
            if lastName.isEmpty == true{
                lastNameError.text = "Name cannot be empty"
                lastNameError.isHidden = false
            }else{
                lastNameError.isHidden = true
            }
        }
        
        checkForValidForm()
    }
    
    
    @IBAction func emailChanged(_ sender: Any) {
        if let email = emailTextFeild.text
                {
                    if let errorMessage = invalidEmail(email)
                    {
                        emailError.text = errorMessage
                        emailError.isHidden = false
                    }
                    else
                    {
                        emailError.isHidden = true
                    }
                }
                
                checkForValidForm()
    }
    
    @IBAction func phoneNumberChanged(_ sender: Any) {
        if let phoneNumber = phoneNumberTextFeild.text
                {
                    if let errorMessage = invalidPhoneNumber(phoneNumber)
                    {
                        phoneError.text = errorMessage
                        phoneError.isHidden = false
                    }
                    else
                    {
                        phoneError.isHidden = true
                    }
                }
                checkForValidForm()
    }
    func invalidPhoneNumber(_ value: String) -> String?
        {
            let set = CharacterSet(charactersIn: value)
            if !CharacterSet.decimalDigits.isSuperset(of: set)
            {
                return "Phone Number must contain only digits"
            }
            
            if value.count != 10
            {
                return "Phone Number must be 10 Digits in Length"
            }
            return nil
        }
    func invalidEmail(_ value: String) -> String?
        {
            let reqularExpression = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
            if !predicate.evaluate(with: value)
            {
                return "Invalid Email Address and must contain domain name"
            }
            
            return nil
        }
    func checkForValidForm()
        {
            if emailError.isHidden && phoneError.isHidden && firstNameError.isHidden && lastNameError.isHidden
            {
                saveBtn.isEnabled = true
            }
            else
            {
                saveBtn.isEnabled = false
            }
        }
    
    @IBAction func deleteButtonActionButton(_ sender: Any) {
        
//        let alert = UIAlertController(title: "Are you sure to delete the contact", message: "Are you sure to delete the contact", preferredStyle: .alert)
//
//
//        let ok = UIAlertAction(title: "ok", style: .default, handler: { (action) -> Void in print("Ok button tapped")
//
//        })
        //self.present(alert, animated: true, completion: nil)
        
        var count: Int = 0
        
        for contact in contactArray{
            
            if contact.firstName == firstNameTextFeild.text! {
                contactArray.remove(at: count)
            }
            count = count + 1
        }
        
        _ = navigationController?.popToRootViewController(animated: true)
        
        
    }
    
    
    @IBAction func saveBtnClicked(_ sender: Any) {
        
        var countUpdate: Int = 0
        
        for contact in contactArray{
            
            if contact.firstName == tempfName{
                contactArray.remove(at: countUpdate)
                var contact=contacts(firstName: firstNameTextFeild.text!, lastName: lastNameTextFeild.text!, email: emailTextFeild.text!, phnNum: Int(phoneNumberTextFeild.text!)!)
                
                contactArray.append(contact)
            }
            countUpdate = countUpdate + 1
        }
        
        _ = navigationController?.popToRootViewController(animated: true)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
