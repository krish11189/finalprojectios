//
//  ContactsModifyViewController.swift
//  ContactListApp
//
//  Created by student on 5/2/22.
//

import UIKit

class ContactsModifyViewController: UIViewController {
    
    
    @IBOutlet weak var firstNameTextFeild: UITextField!
    
    
    @IBOutlet weak var lastNameTextFeild: UITextField!
    
    
    @IBOutlet weak var emailTextFeild: UITextField!
    
    
    @IBOutlet weak var phoneNumberTextFeild: UITextField!
    
    
    @IBOutlet weak var deleteButton: UIButton!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    var fName = ""
    var lName = ""
    var email = ""
    var phnNo: Int = 0
    
    var tempfName = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNameTextFeild.text = contactEdit.firstName
        lastNameTextFeild.text = contactEdit.lastName
        emailTextFeild.text = contactEdit.email
        phoneNumberTextFeild.text = String(contactEdit.phnNum)
        tempfName = firstNameTextFeild.text!

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func deleteButtonActionButton(_ sender: Any) {
        
        var count: Int = 0
        
        for contact in contactArray{
            
            if contact.firstName == firstNameTextFeild.text! {
                contactArray.remove(at: count)
            }
            count = count + 1
        }
        
        _ = navigationController?.popToRootViewController(animated: true)
        
        
    }
    
    
    @IBAction func saveBtnClicked(_ sender: Any) {
        
        var countUpdate: Int = 0
        
        for contact in contactArray{
            
            if contact.firstName == tempfName{
                contactArray.remove(at: countUpdate)
                var contact=contacts(firstName: firstNameTextFeild.text!, lastName: lastNameTextFeild.text!, email: emailTextFeild.text!, phnNum: Int(phoneNumberTextFeild.text!)!)
                
                contactArray.append(contact)
            }
            countUpdate = countUpdate + 1
        }
        
        _ = navigationController?.popToRootViewController(animated: true)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
