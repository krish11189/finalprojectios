//
//  DataFile.swift
//  ContactListApp
//
//  Created by student on 5/2/22.
//

import Foundation

struct contacts {
    var firstName : String = ""
    var lastName : String = ""
    var email : String = ""
    var phnNum : Int = 0
}

var contact1 = contacts(firstName: "Rohith", lastName: "Kondle", email: "rohith@gmail.com", phnNum: 1111111111)
var contact2 = contacts(firstName: "Krishna", lastName: "Katreddy", email: "krishna@gmail.com", phnNum: 2222222222)
var contact3 = contacts(firstName: "Vikram", lastName: "Yadavally", email: "vikram@gmail.com", phnNum: 3333333333)
var contact4 = contacts(firstName: "Mahesh", lastName: "Goli", email: "mahesh@gmail.com", phnNum: 4444444444)
var contact5 = contacts(firstName: "Aparna", lastName: "Sundari", email: "aparna@gmail.com", phnNum: 5555555555)
var contact6 = contacts(firstName: "Varun", lastName: "Pathuri", email: "varun@gmail.com", phnNum: 6666666666)
var contact7 = contacts(firstName: "Sai", lastName: "Kurri", email: "sai@gmail.com", phnNum: 7777777777)
var contact8 = contacts(firstName: "Shashi", lastName: "Nagireddy", email: "shashi@gmail.com", phnNum: 8888888888)
var contact9 = contacts(firstName: "Anil", lastName: "Kolla", email: "anil@gmail.com", phnNum: 9999999999)
var contact10 = contacts(firstName: "Likhitha", lastName: "Gopi", email: "likhitha@gmail.com", phnNum: 0000000000)


var contactArray = [contact1, contact2, contact3, contact4, contact5, contact6, contact7, contact8, contact9, contact10]

var contactEdit:contacts=contacts(firstName: "", lastName: "", email: "", phnNum:0)


