//
//  NewContactViewController.swift
//  ContactListApp
//
//  Created by student on 5/2/22.
//

import UIKit

class NewContactViewController: UIViewController {
    
    
    @IBOutlet weak var firstNameTextFeild: UITextField!
    
    
    @IBOutlet weak var lastNameTextFeild: UITextField!
    
    
    @IBOutlet weak var emailTextFeild: UITextField!
    
    
    @IBOutlet weak var phoneNumberTextFeild: UITextField!
    
    
    @IBOutlet weak var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func saveActionButton(_ sender: UIButton) {
        var contact=contacts(firstName: firstNameTextFeild.text!, lastName: lastNameTextFeild.text!, email: emailTextFeild.text!, phnNum: Int(phoneNumberTextFeild.text!)!)
        
        contactArray.append(contact)
        
        
//
//        var dialogMessage = UIAlertController(title: "Attention", message: "Contact saved", preferredStyle: .alert)

//                    let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
//                        print("Ok button tapped")
                  //   })

                    //Add OK button to a dialog message
//                    dialogMessage.addAction(ok)
                     //Present Alert to
//                    self.present(dialogMessage, animated: true, completion: nil)
//        let displayVC : ViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "home") as! ViewController
//                            self.present(displayVC, animated: true, completion: nil)
        
        _ = navigationController?.popToRootViewController(animated: true)
        
       
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
