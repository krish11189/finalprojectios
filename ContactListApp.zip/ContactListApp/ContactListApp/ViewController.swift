//
//  ViewController.swift
//  ContactListApp
//
//  Created by student on 5/2/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableViewContacts.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        
        cell.textLabel?.text = contactArray[indexPath.row].firstName + " " + contactArray[indexPath.row].lastName
        
        return cell
        
    }
    
    
    
    
    @IBOutlet weak var tableViewContacts: UITableView!
    
    
    @IBOutlet weak var newContactButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewContacts.delegate = self
        tableViewContacts.dataSource = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tableViewContacts.reloadData()
    }
    
    
    @IBAction func newContactActionButton(_ sender: Any) {
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "contactInfoSegue" {
            let destination = segue.destination as! ContactInfoViewController
            
            
            
            destination.fName = contactArray[(tableViewContacts.indexPathForSelectedRow?.row)!].firstName
            
            destination.lName = contactArray[(tableViewContacts.indexPathForSelectedRow?.row)!].lastName
            
            destination.email = contactArray[(tableViewContacts.indexPathForSelectedRow?.row)!].email
            
            destination.phnNo = contactArray[(tableViewContacts.indexPathForSelectedRow?.row)!].phnNum
            
            
            
        }
    }
    

}

